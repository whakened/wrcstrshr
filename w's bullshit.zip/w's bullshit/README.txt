hi!!!!

!! if you need to know how to install please skip to like . halfway down !!

thankyou for maybepossibly playing this shit !! i make these for the Love of the game I Fuckinglove every song I put here and Will be updating this in the future . Several times probably .

i don't think im Great at making these but like . Whatever . all that matters is Yaay Wooo  Music i like that i can PLAY GAME WITH !!!


btwbtwbtw if you can fc bleed or clockworks PLEASE show me 
or even show me youfailing thats cool too .
(interact pleasr )

Anyways . YEAAH sorry all i really have right now is meshuggah charts i had a feeling their shit would work really well and  idk I think i was correct So I Win

also i think this is technically music piracy but thats okay right ?? ,,, right !??????


INSTALLATION

WINDOWS:
uum. so the only two I know are StepMania and Etterna (i use etterna, its alright i guess). for stepmania it's like . '%appdata%/Roaming/StepMania 5/Songs' i think . unzip archive to there . for etterna it's 'C:/Games/Etterna/Songs', unzip archive to there . AWESOME!!! if you use anything else like osu or some shit then DIE !!!! Now

MAC, LINUX:
idk figure it out yourself Loser 



okbye !!